package com.iluwatar.dependencyinjection;

/**
 * 
 * OldTobyTobacco concrete Tobacco implementation
 *
 */
public class OldTobyTobacco extends Tobacco {
}
