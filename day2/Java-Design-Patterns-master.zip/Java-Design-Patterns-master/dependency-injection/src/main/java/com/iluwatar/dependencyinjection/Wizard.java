package com.iluwatar.dependencyinjection;

/**
 * 
 * Wizard interface
 *
 */
public interface Wizard {
	
	void smoke();

}
