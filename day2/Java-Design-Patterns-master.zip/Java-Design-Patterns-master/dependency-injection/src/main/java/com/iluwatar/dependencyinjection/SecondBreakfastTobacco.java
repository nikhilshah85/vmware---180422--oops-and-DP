package com.iluwatar.dependencyinjection;

/**
 * 
 * SecondBreakfastTobacco concrete Tobacco implementation
 *
 */
public class SecondBreakfastTobacco extends Tobacco {
}
