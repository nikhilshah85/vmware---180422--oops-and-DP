package com.iluwatar.dependencyinjection;

/**
 * 
 * RivendellTobacco concrete Tobacco implementation
 *
 */
public class RivendellTobacco extends Tobacco {
}
