package com.iluwatar.specification.app;

import org.junit.Test;

import com.iluwatar.specification.app.App;

public class AppTest {

	@Test
	public void test() {
		String[] args = {};
		App.main(args);
	}
}
