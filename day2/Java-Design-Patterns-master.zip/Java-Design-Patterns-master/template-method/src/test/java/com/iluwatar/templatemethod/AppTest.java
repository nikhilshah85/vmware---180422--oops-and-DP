package com.iluwatar.templatemethod;

import org.junit.Test;

import com.iluwatar.templatemethod.App;

public class AppTest {

	@Test
	public void test() {
		String[] args = {};
		App.main(args);
	}
}
