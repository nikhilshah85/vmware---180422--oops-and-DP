package com.iluwatar.resourceacquisitionisinitialization;

import org.junit.Test;

import com.iluwatar.resourceacquisitionisinitialization.App;

public class AppTest {

	@Test
	public void test() throws Exception {
		String[] args = {};
		App.main(args);
	}
}
