package com.iluwatar.chain;

public enum RequestType {

	DEFEND_CASTLE, TORTURE_PRISONER, COLLECT_TAX

}
