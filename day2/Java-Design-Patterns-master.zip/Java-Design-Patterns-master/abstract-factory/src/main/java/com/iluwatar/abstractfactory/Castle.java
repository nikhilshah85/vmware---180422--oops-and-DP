package com.iluwatar.abstractfactory;

public interface Castle {

}
