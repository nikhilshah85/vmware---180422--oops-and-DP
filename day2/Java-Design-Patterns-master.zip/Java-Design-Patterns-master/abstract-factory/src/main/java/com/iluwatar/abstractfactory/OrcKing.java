package com.iluwatar.abstractfactory;

public class OrcKing implements King {

	@Override
	public String toString() {
		return "This is the Orc king!";
	}

}
