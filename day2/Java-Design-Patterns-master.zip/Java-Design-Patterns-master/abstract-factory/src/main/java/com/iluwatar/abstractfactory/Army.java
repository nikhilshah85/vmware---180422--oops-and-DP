package com.iluwatar.abstractfactory;

public interface Army {

}
