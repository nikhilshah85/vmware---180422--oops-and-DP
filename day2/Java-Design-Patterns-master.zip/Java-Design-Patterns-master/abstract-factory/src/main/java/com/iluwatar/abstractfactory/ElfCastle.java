package com.iluwatar.abstractfactory;

public class ElfCastle implements Castle {

	@Override
	public String toString() {
		return "This is the Elven castle!";
	}

}
