package com.iluwatar.abstractfactory;

public class OrcCastle implements Castle {

	@Override
	public String toString() {
		return "This is the Orcish castle!";
	}

}
