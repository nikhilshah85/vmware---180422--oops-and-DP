package com.iluwatar.abstractfactory;

public class ElfKing implements King {

	@Override
	public String toString() {
		return "This is the Elven king!";
	}

}
