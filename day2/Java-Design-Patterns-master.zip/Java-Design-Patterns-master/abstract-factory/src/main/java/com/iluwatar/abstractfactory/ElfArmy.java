package com.iluwatar.abstractfactory;

public class ElfArmy implements Army {

	@Override
	public String toString() {
		return "This is the Elven Army!";
	}

}
