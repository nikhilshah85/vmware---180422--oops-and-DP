package com.iluwatar.abstractfactory;

public class OrcArmy implements Army {

	@Override
	public String toString() {
		return "This is the Orcish Army!";
	}

}
