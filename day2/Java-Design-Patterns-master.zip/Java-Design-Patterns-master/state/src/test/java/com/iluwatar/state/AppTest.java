package com.iluwatar.state;

import org.junit.Test;

import com.iluwatar.state.App;

public class AppTest {

	@Test
	public void test() {
		String[] args = {};
		App.main(args);
	}
}
