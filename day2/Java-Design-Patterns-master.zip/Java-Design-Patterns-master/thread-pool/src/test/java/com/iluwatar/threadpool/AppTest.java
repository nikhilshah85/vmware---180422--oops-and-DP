package com.iluwatar.threadpool;

import org.junit.Test;

import com.iluwatar.threadpool.App;

public class AppTest {
	
	@Test
	public void test() {
		String[] args = {};
		App.main(args);
	}
}
