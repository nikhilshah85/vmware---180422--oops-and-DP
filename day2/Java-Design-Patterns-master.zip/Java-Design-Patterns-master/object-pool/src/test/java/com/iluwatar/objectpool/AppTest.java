package com.iluwatar.objectpool;

import org.junit.Test;

import com.iluwatar.objectpool.App;

public class AppTest {
	
	@Test
	public void test() {
		String[] args = {};
		App.main(args);
	}
}
