package com.iluwatar.multiton;

/**
 * 
 * Each Nazgul has different NazgulName.
 *
 */
public enum NazgulName {

	KHAMUL, MURAZOR, DWAR, JI_INDUR, AKHORAHIL, HOARMURATH, ADUNAPHEL, REN, UVATHA;
	
}
