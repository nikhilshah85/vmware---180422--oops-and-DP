package com.iluwatar.eventaggregator;
import org.junit.Test;

import com.iluwatar.eventaggregator.App;

public class AppTest {

	@Test
	public void test() {
		String[] args = {};
		App.main(args);
	}
}
