package com.iluwatar.bridge;

public abstract class FlyingMagicWeaponImp extends MagicWeaponImp {

	public abstract void flyImp();

}
