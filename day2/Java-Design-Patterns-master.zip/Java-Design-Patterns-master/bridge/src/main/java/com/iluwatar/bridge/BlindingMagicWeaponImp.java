package com.iluwatar.bridge;

public abstract class BlindingMagicWeaponImp extends MagicWeaponImp {

	public abstract void blindImp();

}
