package com.iluwatar.bridge;

public abstract class SoulEatingMagicWeaponImp extends MagicWeaponImp {

	public abstract void eatSoulImp();

}
