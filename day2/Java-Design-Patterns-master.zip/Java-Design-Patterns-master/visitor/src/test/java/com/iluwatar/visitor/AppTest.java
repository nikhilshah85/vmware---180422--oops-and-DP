package com.iluwatar.visitor;

import org.junit.Test;

import com.iluwatar.visitor.App;

public class AppTest {

	@Test
	public void test() {
		String[] args = {};
		App.main(args);
	}
}
