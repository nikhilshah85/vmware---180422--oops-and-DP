package com.iluwatar.dao;

import org.junit.Test;

import com.iluwatar.dao.App;

public class AppTest {

	@Test
	public void test() {
		String[] args = {};
		App.main(args);
	}
}
