package com.iluwatar.poisonpill;

import org.junit.Test;

import com.iluwatar.poisonpill.App;

public class AppTest {

	@Test
	public void test() {
		String[] args = {};
		App.main(args);
	}
}
