package com.iluwatar.factorymethod;

public interface Weapon {

}
