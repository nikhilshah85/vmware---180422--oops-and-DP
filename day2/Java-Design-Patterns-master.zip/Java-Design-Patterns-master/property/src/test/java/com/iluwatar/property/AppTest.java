package com.iluwatar.property;

import org.junit.Test;

import com.iluwatar.property.App;

public class AppTest {

	@Test
	public void test() {
		String[] args = {};
		App.main(args);
	}
}
