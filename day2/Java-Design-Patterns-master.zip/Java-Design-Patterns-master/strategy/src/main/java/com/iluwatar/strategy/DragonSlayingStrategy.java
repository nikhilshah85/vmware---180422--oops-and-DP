package com.iluwatar.strategy;

/**
 * 
 * Strategy interface.
 * 
 */
public interface DragonSlayingStrategy {

	void execute();

}
