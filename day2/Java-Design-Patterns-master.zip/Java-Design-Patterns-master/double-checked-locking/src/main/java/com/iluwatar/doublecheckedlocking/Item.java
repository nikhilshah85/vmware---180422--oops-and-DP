package com.iluwatar.doublecheckedlocking;

public class Item {
	String name;
	int level;
}
