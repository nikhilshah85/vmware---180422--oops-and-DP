package com.iluwatar.servicelayer.app;

import org.junit.Test;

import com.iluwatar.servicelayer.app.App;

public class AppTest {
	
	@Test
	public void test() {
		String[] args = {};
		App.main(args);
	}
}
