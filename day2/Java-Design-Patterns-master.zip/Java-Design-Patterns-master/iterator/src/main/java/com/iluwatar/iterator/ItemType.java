package com.iluwatar.iterator;

public enum ItemType {

	ANY, WEAPON, RING, POTION

}
