package com.iluwatar.iterator;

/**
 * 
 * Iterator interface.
 * 
 */
public interface ItemIterator {

	boolean hasNext();

	Item next();
}
