package com.iluwatar.adapter;

/**
 * 
 * Engineers can operate devices.
 * 
 */
public interface Engineer {

	void operateDevice();

}
