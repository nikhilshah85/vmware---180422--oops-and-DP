package com.iluwatar.memento;

import org.junit.Test;

import com.iluwatar.memento.App;

public class AppTest {

	@Test
	public void test() {
		String[] args = {};
		App.main(args);
	}
}
