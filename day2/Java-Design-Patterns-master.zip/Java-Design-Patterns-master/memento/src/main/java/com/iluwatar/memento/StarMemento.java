package com.iluwatar.memento;

/**
 * 
 * External interface to memento.
 * 
 */
public interface StarMemento {

}
