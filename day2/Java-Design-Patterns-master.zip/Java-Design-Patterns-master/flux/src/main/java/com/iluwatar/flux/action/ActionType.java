package com.iluwatar.flux.action;

/**
 * 
 * Types of actions.
 *
 */
public enum ActionType {

	MENU_ITEM_SELECTED, CONTENT_CHANGED;
	
}
