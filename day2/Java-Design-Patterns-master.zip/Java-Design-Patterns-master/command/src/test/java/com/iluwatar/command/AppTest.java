package com.iluwatar.command;

import org.junit.Test;

import com.iluwatar.command.App;

public class AppTest {

	@Test
	public void test() {
		String[] args = {};
		App.main(args);
	}
}
