package com.iluwatar.mediator;

/**
 * 
 * Wizard party member.
 *
 */
public class Wizard extends PartyMemberBase {

	@Override
	public String toString() {
		return "Wizard";
	}

}
