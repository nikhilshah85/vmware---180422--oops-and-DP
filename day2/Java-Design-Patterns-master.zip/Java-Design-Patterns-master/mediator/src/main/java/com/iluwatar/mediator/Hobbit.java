package com.iluwatar.mediator;

/**
 * 
 * Hobbit party member.
 *
 */
public class Hobbit extends PartyMemberBase {

	@Override
	public String toString() {
		return "Hobbit";
	}

}
