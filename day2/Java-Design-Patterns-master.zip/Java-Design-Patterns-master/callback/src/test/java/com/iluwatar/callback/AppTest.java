package com.iluwatar.callback;

import org.junit.Test;

import com.iluwatar.callback.App;

public class AppTest {

	@Test
	public void test() {
		String[] args = {};
		App.main(args);
	}
}
