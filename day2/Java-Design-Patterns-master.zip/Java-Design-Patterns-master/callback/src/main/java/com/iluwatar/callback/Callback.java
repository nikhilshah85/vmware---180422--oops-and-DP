package com.iluwatar.callback;

/**
 * Callback interface
 */
public interface Callback {

	public void call();
}
