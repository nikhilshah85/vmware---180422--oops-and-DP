package com.iluwatar.composite;

import org.junit.Test;

import com.iluwatar.composite.App;

public class AppTest {

	@Test
	public void test() {
		String[] args = {};
		App.main(args);
	}
}
