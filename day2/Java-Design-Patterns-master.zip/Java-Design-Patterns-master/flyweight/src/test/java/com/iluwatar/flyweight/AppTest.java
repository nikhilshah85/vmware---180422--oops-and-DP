package com.iluwatar.flyweight;

import org.junit.Test;

import com.iluwatar.flyweight.App;

public class AppTest {

	@Test
	public void test() {
		String[] args = {};
		App.main(args);
	}
}
